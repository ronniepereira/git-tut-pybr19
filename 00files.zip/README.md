# git-tutorial-pybr15

---

Este repositório é um code-along desenvolvido na Python Brasil 15 durante o tutorial "GIT: Sua maior arma durante o Inverno que Está Chegando".

Mais informações no [repositório oficial no github](https://github.com/giuliocc/git-tut-pybr15).

---

#### Contatos:

@ giuliocc (github, telegram)
